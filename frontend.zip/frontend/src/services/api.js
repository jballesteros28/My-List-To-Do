export const API_URL = import.meta.env.VITE_API_UR; // Cambia el puerto si tu backend usa otro
